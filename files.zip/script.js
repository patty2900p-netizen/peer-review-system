(function () {
  "use strict";

  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Footer year ---------- */
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Sticky header shadow + mobile nav ---------- */
  var header = document.getElementById("siteHeader");
  var navToggle = document.getElementById("navToggle");

  function onScroll() {
    if (window.scrollY > 12) {
      header.classList.add("is-scrolled");
    } else {
      header.classList.remove("is-scrolled");
    }
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  if (navToggle && header) {
    navToggle.addEventListener("click", function () {
      var isOpen = header.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      navToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
    });

    header.querySelectorAll(".main-nav a, .header-cta a").forEach(function (link) {
      link.addEventListener("click", function () {
        header.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
        navToggle.setAttribute("aria-label", "Open menu");
      });
    });
  }

  /* ---------- 24-hour check-in strip ---------- */
  var track = document.getElementById("clockTrack");
  var nowMarker = document.getElementById("clockNow");
  var nowLabel = document.getElementById("nowLabel");

  var sampleCheckIns = [
    { hour: 4.9, name: "Priya, marathon block" },
    { hour: 5.6, name: "Karan, before his shift" },
    { hour: 6.3, name: "Group coaching, 6am" },
    { hour: 7.4, name: "Simran, before school run" },
    { hour: 9.1, name: "Off-peak floor opens" },
    { hour: 12.5, name: "Lunch-break lifters" },
    { hour: 17.8, name: "After-work rush" },
    { hour: 19.2, name: "Evening coaching" },
    { hour: 22.4, name: "Fahad, after closing shift" },
    { hour: 23.6, name: "Overnight floor, quiet" },
    { hour: 1.3, name: "Overnight floor, quiet" },
    { hour: 2.8, name: "Nurse finishing night rotation" }
  ];

  function placeDots() {
    if (!track) return;
    sampleCheckIns.forEach(function (entry) {
      var dot = document.createElement("div");
      dot.className = "clock-dot";
      dot.style.left = (entry.hour / 24) * 100 + "%";
      dot.title = formatHour(entry.hour) + " — " + entry.name;
      track.appendChild(dot);
    });
  }

  function formatHour(decimalHour) {
    var h = Math.floor(decimalHour);
    var m = Math.round((decimalHour - h) * 60);
    var period = h >= 12 ? "pm" : "am";
    var displayHour = h % 12;
    if (displayHour === 0) displayHour = 12;
    var mm = m < 10 ? "0" + m : String(m);
    return displayHour + ":" + mm + period;
  }

  function positionNow() {
    if (!nowMarker || !nowLabel) return;
    var now = new Date();
    var decimalHour = now.getHours() + now.getMinutes() / 60;
    nowMarker.style.left = (decimalHour / 24) * 100 + "%";
    nowLabel.textContent = "Now — " + formatHour(decimalHour);
  }

  placeDots();
  positionNow();
  if (!prefersReducedMotion) {
    setInterval(positionNow, 60000);
  }

  /* ---------- Membership billing toggle ---------- */
  var billingSwitch = document.getElementById("billingSwitch");
  var amounts = document.querySelectorAll(".amt");
  var monthlyLabel = document.getElementById("toggleMonthlyLabel");
  var annualLabel = document.getElementById("toggleAnnualLabel");

  function setBilling(isAnnual) {
    billingSwitch.setAttribute("aria-checked", isAnnual ? "true" : "false");
    amounts.forEach(function (el) {
      var value = isAnnual ? el.getAttribute("data-annual") : el.getAttribute("data-monthly");
      el.textContent = "$" + value;
    });
    monthlyLabel.style.color = isAnnual ? "var(--text-low)" : "var(--text-hi)";
    annualLabel.style.color = isAnnual ? "var(--text-hi)" : "var(--text-low)";
  }

  if (billingSwitch) {
    billingSwitch.addEventListener("click", function () {
      var isAnnual = billingSwitch.getAttribute("aria-checked") === "true";
      setBilling(!isAnnual);
    });
    setBilling(false);
  }

  /* ---------- FAQ accordion ---------- */
  var triggers = document.querySelectorAll(".accordion-trigger");

  triggers.forEach(function (trigger) {
    var panel = trigger.parentElement.nextElementSibling;
    panel.style.maxHeight = "0px";

    trigger.addEventListener("click", function () {
      var isOpen = trigger.getAttribute("aria-expanded") === "true";

      triggers.forEach(function (otherTrigger) {
        var otherPanel = otherTrigger.parentElement.nextElementSibling;
        otherTrigger.setAttribute("aria-expanded", "false");
        otherPanel.style.maxHeight = "0px";
      });

      if (!isOpen) {
        trigger.setAttribute("aria-expanded", "true");
        panel.style.maxHeight = panel.scrollHeight + "px";
      }
    });
  });

  /* ---------- Join form validation ---------- */
  var form = document.getElementById("joinForm");
  var formStatus = document.getElementById("formStatus");

  function showError(fieldId, message) {
    var input = document.getElementById(fieldId);
    var errorEl = document.getElementById("err-" + fieldId);
    if (input) input.classList.add("has-error");
    if (errorEl) errorEl.textContent = message;
  }

  function clearError(fieldId) {
    var input = document.getElementById(fieldId);
    var errorEl = document.getElementById("err-" + fieldId);
    if (input) input.classList.remove("has-error");
    if (errorEl) errorEl.textContent = "";
  }

  function isValidEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function isValidPhone(value) {
    var digits = value.replace(/\D/g, "");
    return digits.length >= 7;
  }

  if (form) {
    ["fullName", "email", "phone"].forEach(function (fieldId) {
      var input = document.getElementById(fieldId);
      if (input) {
        input.addEventListener("input", function () {
          clearError(fieldId);
        });
      }
    });

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var valid = true;

      var fullName = document.getElementById("fullName").value.trim();
      var email = document.getElementById("email").value.trim();
      var phone = document.getElementById("phone").value.trim();

      if (fullName.length < 2) {
        showError("fullName", "Enter your full name.");
        valid = false;
      } else {
        clearError("fullName");
      }

      if (!isValidEmail(email)) {
        showError("email", "Enter a valid email address.");
        valid = false;
      } else {
        clearError("email");
      }

      if (!isValidPhone(phone)) {
        showError("phone", "Enter a valid phone number.");
        valid = false;
      } else {
        clearError("phone");
      }

      if (!valid) {
        formStatus.textContent = "";
        return;
      }

      formStatus.textContent = "Thanks, " + fullName.split(" ")[0] + " — check your phone for the fob code shortly.";
      form.reset();
    });
  }
})();
